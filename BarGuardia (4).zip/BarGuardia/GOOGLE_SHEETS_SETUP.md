# Configuración de Google Sheets como Base de Datos

Sigue estos pasos para conectar tu aplicación con Google Sheets:

## 1. Crear la Hoja de Cálculo
1. Ve a [Google Sheets](https://sheets.google.com) y crea una nueva hoja en blanco.
2. Nómbrala "BarGuardia DB" (o como prefieras).
3. Crea las siguientes pestañas (hojas) en la parte inferior, con estos nombres exactos:
   - `Users`
   - `Products`
   - `Sales`
   - `CashRegister`
   - `Tables`

## 2. Configurar el Script
1. En tu hoja de cálculo, ve al menú **Extensiones** > **Apps Script**.
2. Se abrirá una nueva pestaña con un editor de código.
3. Borra cualquier código que haya en el archivo `Code.gs`.
4. Copia TODO el contenido del archivo `google_script.gs` que he creado en tu proyecto (está en la carpeta raíz) y pégalo en el editor de Apps Script.
5. Presiona `Ctrl + S` para guardar el proyecto. Ponle un nombre como "Bar API".

## 3. Publicar la API
1. En la esquina superior derecha, haz clic en el botón azul **Implantar** (Deploy) > **Nueva implementación** (New deployment).
2. En la ventana que aparece, haz clic en el icono de engranaje (Configuración) a la izquierda y selecciona **Aplicación web**.
3. Rellena los campos así:
   - **Descripción**: Bar API
   - **Ejecutar como**: Yo (Me)
   - **Quién tiene acceso**: Cualquier usuario (Anyone)  <-- **IMPORTANTE**
4. Haz clic en **Implantar**.
5. Te pedirá autorización. Haz clic en "Autorizar acceso", selecciona tu cuenta de Google.
   - Si sale una advertencia de "Google no ha verificado esta aplicación", haz clic en "Advanced" (Avanzado) y luego en "Go to Bar API (unsafe)" (Ir a Bar API (no seguro)).
   - Haz clic en "Allow" (Permitir).
6. Copia la **URL de la aplicación web** (Web App URL) que te dará al final. Empieza por `https://script.google.com/macros/s/...`.

## 4. Conectar con la App
1. Vuelve a este chat y pégame la URL que acabas de copiar.
2. Yo configuraré la aplicación para que use esa URL para guardar y leer los datos.
