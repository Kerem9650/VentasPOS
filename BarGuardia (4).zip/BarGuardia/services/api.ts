import { User, Product, Sale, CashRegisterState, TableOrder } from '../types';

const API_URL = 'https://script.google.com/macros/s/AKfycbx2CKxmlf88YSeQZoMd6LDYfUkhUl04QPuWSzZ1fssYjaaM2BZ_jRfWQS7BpS8gLzzY8g/exec';

export const api = {
    async getData() {
        try {
            const response = await fetch(`${API_URL}?action=getData`, {
                method: 'GET',
            });
            if (!response.ok) throw new Error('Network response was not ok');
            const data = await response.json();
            console.log('getData response:', data);
            return data;
        } catch (error) {
            console.error('Error fetching data:', error);
            return null;
        }
    },

    async saveData(action: string, payload: any) {
        try {
            console.log(`Sending ${action} with payload:`, payload);

            const response = await fetch(API_URL, {
                method: 'POST',
                body: JSON.stringify({
                    action,
                    payload
                })
            });

            const result = await response.json();
            console.log(`${action} response:`, result);
            return result;
        } catch (error) {
            console.error(`Error in ${action}:`, error);
            return null;
        }
    },

    async saveUsers(users: User[]) {
        return this.saveData('saveUsers', users);
    },

    async saveProducts(products: Product[]) {
        return this.saveData('saveProducts', products);
    },

    async saveSales(sales: Sale[]) {
        return this.saveData('saveSales', sales);
    },

    async saveCashState(state: CashRegisterState) {
        return this.saveData('saveCash', state);
    },

    async saveTables(tables: TableOrder[]) {
        return this.saveData('saveTables', tables);
    }
};
