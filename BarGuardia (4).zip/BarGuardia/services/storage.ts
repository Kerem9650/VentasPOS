import { Product, Sale, User, CashRegisterState, TableOrder } from '../types';

const KEYS = {
  USERS: 'lg_users',
  PRODUCTS: 'lg_products',
  SALES: 'lg_sales',
  CASH: 'lg_cash',
  TABLES: 'lg_tables'
};

export const storage = {
  getUsers: (defaults: User[]): User[] => {
    const data = localStorage.getItem(KEYS.USERS);
    return data ? JSON.parse(data) : defaults;
  },
  saveUsers: (users: User[]) => localStorage.setItem(KEYS.USERS, JSON.stringify(users)),

  getProducts: (defaults: Product[]): Product[] => {
    const data = localStorage.getItem(KEYS.PRODUCTS);
    return data ? JSON.parse(data) : defaults;
  },
  saveProducts: (products: Product[]) => localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products)),

  getSales: (): Sale[] => {
    const data = localStorage.getItem(KEYS.SALES);
    return data ? JSON.parse(data) : [];
  },
  saveSales: (sales: Sale[]) => localStorage.setItem(KEYS.SALES, JSON.stringify(sales)),

  getCashState: (defaults: CashRegisterState): CashRegisterState => {
    const data = localStorage.getItem(KEYS.CASH);
    return data ? JSON.parse(data) : defaults;
  },
  saveCashState: (state: CashRegisterState) => localStorage.setItem(KEYS.CASH, JSON.stringify(state)),

  getTables: (defaults: TableOrder[]): TableOrder[] => {
    const data = localStorage.getItem(KEYS.TABLES);
    return data ? JSON.parse(data) : defaults;
  },
  saveTables: (tables: TableOrder[]) => localStorage.setItem(KEYS.TABLES, JSON.stringify(tables))
};
