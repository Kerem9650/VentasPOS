import React, { useState, useEffect } from 'react';
import { Save, RefreshCw, Moon, Sun } from 'lucide-react';

interface ThemeConfig {
    primary: string;
    primaryHover: string;
    bgMain: string;
    bgPaper: string;
    textMain: string;
    textSecondary: string;
}

const DEFAULT_DARK: ThemeConfig = {
    primary: '#d97706',
    primaryHover: '#b45309',
    bgMain: '#111827',
    bgPaper: '#1f2937',
    textMain: '#f3f4f6',
    textSecondary: '#9ca3af',
};

const DEFAULT_LIGHT: ThemeConfig = {
    primary: '#d97706',
    primaryHover: '#b45309',
    bgMain: '#f3f4f6',
    bgPaper: '#ffffff',
    textMain: '#111827',
    textSecondary: '#4b5563',
};

export const Settings = () => {
    const [mode, setMode] = useState<'dark' | 'light'>('dark');
    const [config, setConfig] = useState<ThemeConfig>(DEFAULT_DARK);

    useEffect(() => {
        // Load saved settings if any (mock implementation for now, will rely on App state in real integration)
        const saved = localStorage.getItem('theme_config');
        if (saved) {
            setConfig(JSON.parse(saved));
        }
    }, []);

    const applyTheme = (newConfig: ThemeConfig) => {
        const root = document.documentElement;
        root.style.setProperty('--primary', newConfig.primary);
        root.style.setProperty('--primary-hover', newConfig.primaryHover);
        root.style.setProperty('--bg-main', newConfig.bgMain);
        root.style.setProperty('--bg-paper', newConfig.bgPaper);
        root.style.setProperty('--text-main', newConfig.textMain);
        root.style.setProperty('--text-secondary', newConfig.textSecondary);
        setConfig(newConfig);
        localStorage.setItem('theme_config', JSON.stringify(newConfig));
    };

    const handleModeChange = (newMode: 'dark' | 'light') => {
        setMode(newMode);
        if (newMode === 'light') applyTheme(DEFAULT_LIGHT);
        else applyTheme(DEFAULT_DARK);
    };

    const handleChange = (key: keyof ThemeConfig, value: string) => {
        const newConfig = { ...config, [key]: value };
        applyTheme(newConfig);
    };

    return (
        <div className="p-6 h-full overflow-y-auto bg-app-bg text-app-text">
            <h2 className="text-2xl font-bold mb-6 text-primary">Configuración del Sistema</h2>

            <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Theme Presets */}
                <div className="bg-app-paper p-6 rounded-lg shadow-lg">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                        <Sun size={24} />
                        Modo
                    </h3>
                    <div className="flex gap-4">
                        <button
                            onClick={() => handleModeChange('light')}
                            className={`flex-1 p-4 rounded border-2 flex flex-col items-center gap-2 ${mode === 'light' ? 'border-primary bg-primary/20' : 'border-gray-600'}`}
                        >
                            <Sun size={32} />
                            <span>Claro</span>
                        </button>
                        <button
                            onClick={() => handleModeChange('dark')}
                            className={`flex-1 p-4 rounded border-2 flex flex-col items-center gap-2 ${mode === 'dark' ? 'border-primary bg-primary/20' : 'border-gray-600'}`}
                        >
                            <Moon size={32} />
                            <span>Oscuro</span>
                        </button>
                    </div>
                </div>

                {/* Color Palette */}
                <div className="bg-app-paper p-6 rounded-lg shadow-lg">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                        <RefreshCw size={24} />
                        Paleta de Colores
                    </h3>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium mb-1">Color Primario (Botones/Info)</label>
                            <div className="flex gap-2">
                                <input
                                    type="color"
                                    value={config.primary}
                                    onChange={(e) => handleChange('primary', e.target.value)}
                                    className="h-10 w-20 rounded cursor-pointer"
                                />
                                <input
                                    type="text"
                                    value={config.primary}
                                    onChange={(e) => handleChange('primary', e.target.value)}
                                    className="flex-1 bg-app-bg text-app-text border border-gray-600 rounded px-3 py-2"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium mb-1">Fondo Principal</label>
                            <div className="flex gap-2">
                                <input
                                    type="color"
                                    value={config.bgMain}
                                    onChange={(e) => handleChange('bgMain', e.target.value)}
                                    className="h-10 w-20 rounded cursor-pointer"
                                />
                                <input
                                    type="text"
                                    value={config.bgMain}
                                    onChange={(e) => handleChange('bgMain', e.target.value)}
                                    className="flex-1 bg-app-bg text-app-text border border-gray-600 rounded px-3 py-2"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium mb-1">Fondo Tarjetas / Paneles</label>
                            <div className="flex gap-2">
                                <input
                                    type="color"
                                    value={config.bgPaper}
                                    onChange={(e) => handleChange('bgPaper', e.target.value)}
                                    className="h-10 w-20 rounded cursor-pointer"
                                />
                                <input
                                    type="text"
                                    value={config.bgPaper}
                                    onChange={(e) => handleChange('bgPaper', e.target.value)}
                                    className="flex-1 bg-app-bg text-app-text border border-gray-600 rounded px-3 py-2"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium mb-1">Texto Principal</label>
                            <div className="flex gap-2">
                                <input
                                    type="color"
                                    value={config.textMain}
                                    onChange={(e) => handleChange('textMain', e.target.value)}
                                    className="h-10 w-20 rounded cursor-pointer"
                                />
                                <input
                                    type="text"
                                    value={config.textMain}
                                    onChange={(e) => handleChange('textMain', e.target.value)}
                                    className="flex-1 bg-app-bg text-app-text border border-gray-600 rounded px-3 py-2"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
