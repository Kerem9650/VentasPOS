import React, { useState } from 'react';
import { User, Role } from '../types';
import { Trash2, Plus, User as UserIcon } from 'lucide-react';

interface AdminUsersProps {
  currentUser: User;
  users: User[];
  onUpdateUsers: (users: User[]) => void;
}

export const AdminUsers: React.FC<AdminUsersProps> = ({ currentUser, users, onUpdateUsers }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newUser, setNewUser] = useState<Partial<User>>({ role: Role.SELLER });

  if (currentUser.role !== Role.ADMIN) return null;

  const handleAdd = () => {
    if (!newUser.username || !newUser.password || !newUser.name) return alert('Complete todos los campos');

    const user: User = {
      id: crypto.randomUUID(),
      username: newUser.username,
      password: newUser.password,
      name: newUser.name,
      role: newUser.role || Role.SELLER
    };

    onUpdateUsers([...users, user]);
    setIsAdding(false);
    setNewUser({ role: Role.SELLER });
  };

  const handleDelete = (id: string) => {
    if (id === currentUser.id) return alert('No puedes eliminarte a ti mismo');
    if (window.confirm('¿Eliminar usuario?')) {
      onUpdateUsers(users.filter(u => u.id !== id));
    }
  };

  return (
    <div className="p-6 bg-app-bg min-h-full">
      <h2 className="text-2xl font-bold text-primary mb-6">Gestión de Usuarios</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map(u => (
          <div key={u.id} className="bg-app-paper p-6 rounded-lg border border-gray-700 relative">
            <div className="flex items-center gap-4 mb-4">
              <div className="bg-gray-700 p-3 rounded-full">
                <UserIcon className="w-6 h-6 text-app-text" />
              </div>
              <div>
                <p className="font-bold text-lg">{u.name}</p>
                <p className="text-sm text-app-muted">@{u.username}</p>
              </div>
            </div>
            <div className="mb-4">
              <span className={`px-2 py-1 rounded text-xs font-bold ${u.role === Role.ADMIN ? 'bg-amber-900 text-amber-200' : 'bg-blue-900 text-blue-200'}`}>
                {u.role}
              </span>
            </div>
            {u.id !== currentUser.id && (
              <button
                onClick={() => handleDelete(u.id)}
                className="absolute top-4 right-4 text-app-muted hover:text-red-500 transition-colors"
              >
                <Trash2 size={20} />
              </button>
            )}
          </div>
        ))}

        {/* Add Button Card */}
        {!isAdding ? (
          <button
            onClick={() => setIsAdding(true)}
            className="bg-app-paper/50 border-2 border-dashed border-gray-700 hover:border-primary rounded-lg flex flex-col items-center justify-center p-6 text-app-muted hover:text-primary transition-all min-h-[160px]"
          >
            <Plus size={40} />
            <span className="mt-2 font-medium">Crear Usuario</span>
          </button>
        ) : (
          <div className="bg-app-paper p-6 rounded-lg border border-primary">
            <h3 className="font-bold mb-4">Nuevo Usuario</h3>
            <input
              className="w-full mb-2 bg-app-bg text-app-text p-2 rounded border border-gray-700"
              placeholder="Nombre Completo"
              onChange={e => setNewUser({ ...newUser, name: e.target.value })}
            />
            <input
              className="w-full mb-2 bg-app-bg text-app-text p-2 rounded border border-gray-700"
              placeholder="Usuario (Login)"
              onChange={e => setNewUser({ ...newUser, username: e.target.value })}
            />
            <input
              className="w-full mb-2 bg-app-bg text-app-text p-2 rounded border border-gray-700"
              placeholder="Contraseña"
              type="password"
              onChange={e => setNewUser({ ...newUser, password: e.target.value })}
            />
            <select
              className="w-full mb-4 bg-app-bg text-app-text p-2 rounded border border-gray-700"
              value={newUser.role}
              onChange={e => setNewUser({ ...newUser, role: e.target.value as Role })}
            >
              <option value={Role.SELLER}>VENDEDOR</option>
              <option value={Role.ADMIN}>ADMINISTRADOR</option>
              <option value={Role.KITCHEN}>COCINA</option>
              <option value={Role.BOX}>CAJA</option>
            </select>
            <div className="flex gap-2">
              <button onClick={handleAdd} className="flex-1 bg-green-600 rounded py-2">Guardar</button>
              <button onClick={() => setIsAdding(false)} className="flex-1 bg-gray-600 rounded py-2">Cancelar</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
