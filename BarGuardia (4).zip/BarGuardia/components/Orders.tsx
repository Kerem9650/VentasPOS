import React from 'react';
import { TableOrder } from '../types';
import { ClipboardList, CheckCircle, Clock, Check } from 'lucide-react';

interface OrdersProps {
    tables: TableOrder[];
    onUpdateTables: (tables: TableOrder[]) => void;
}

export const Orders: React.FC<OrdersProps> = ({ tables, onUpdateTables }) => {
    const activeTables = tables.filter(t => t.items.length > 0);

    const toggleStatus = (tableId: string, currentStatus: 'PENDIENTE' | 'ENTREGADO') => {
        const newStatus = currentStatus === 'PENDIENTE' ? 'ENTREGADO' : 'PENDIENTE';
        onUpdateTables(tables.map(t => t.id === tableId ? { ...t, orderStatus: newStatus } : t));
    };

    return (
        <div className="p-6 bg-app-bg min-h-full">
            <h2 className="text-2xl font-bold text-app-text mb-6 flex items-center gap-2">
                <ClipboardList size={24} className="text-primary" /> Pedidos
            </h2>

            {activeTables.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-10 bg-app-paper rounded border border-gray-700">
                    <CheckCircle size={48} className="text-green-500 mb-4" />
                    <h3 className="text-xl font-bold text-app-text">No hay pedidos pendientes</h3>
                    <p className="text-app-text mt-2">Todos los pedidos han sido despachados o no hay mesas activas.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {activeTables.map(table => (
                        <div key={table.id} className={`bg-app-paper rounded-lg border-l-4 shadow-lg overflow-hidden ${table.orderStatus === 'ENTREGADO' ? 'border-green-500 opacity-80' : 'border-primary'}`}>
                            <div className="p-4 bg-app-paper border-b border-gray-700 flex justify-between items-center">
                                <h3 className="text-xl font-bold text-app-text">{table.id}</h3>
                                <button
                                    onClick={() => toggleStatus(table.id, table.orderStatus)}
                                    className={`flex items-center gap-1 px-3 py-1 rounded text-xs font-bold transition-colors ${table.orderStatus === 'ENTREGADO'
                                        ? 'bg-green-900/50 text-green-300 hover:bg-green-900'
                                        : 'bg-primary/30 text-primary hover:bg-primary/50'
                                        }`}
                                >
                                    {table.orderStatus === 'ENTREGADO' ? <Check size={12} /> : <Clock size={12} />}
                                    {table.orderStatus || 'PENDIENTE'}
                                </button>
                            </div>
                            <div className="p-4">
                                <ul className="space-y-3">
                                    {table.items.map((item, idx) => (
                                        <li key={idx} className="flex justify-between items-center text-sm border-b border-gray-700/50 pb-2 last:border-0 last:pb-0">
                                            <div className="flex items-center gap-2">
                                                <span className="bg-gray-700 text-app-text font-bold w-6 h-6 flex items-center justify-center rounded-full text-xs">
                                                    {item.quantity}
                                                </span>
                                                <span className={`text-app-text ${table.orderStatus === 'ENTREGADO' ? 'line-through text-app-muted' : ''}`}>
                                                    {item.name}
                                                </span>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="p-3 bg-app-paper/30 text-center text-xs text-app-muted">
                                {table.items.reduce((acc, i) => acc + i.quantity, 0)} items en total
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};
