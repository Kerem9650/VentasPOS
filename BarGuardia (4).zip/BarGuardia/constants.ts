import { User, Role, Product, TableOrder } from './types';

export const INITIAL_USERS: User[] = [
  {
    id: 'u1',
    username: 'admin',
    password: 'Ricardobgil1001*',
    role: Role.ADMIN,
    name: 'Administrador'
  },
  {
    id: 'u2',
    username: 'vendedor',
    password: 'Ventas2026*',
    role: Role.SELLER,
    name: 'Vendedor'
  },
  {
    id: 'u3',
    username: 'cocina',
    password: 'Cocina2025*',
    role: Role.KITCHEN,
    name: 'Cocina / Barra'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  { id: 1, name: 'Cerveza Club Colombia', buyPrice: 3000, sellPrice: 6000, stock: 50 },
  { id: 2, name: 'Cerveza Aguila', buyPrice: 2800, sellPrice: 5000, stock: 60 },
  { id: 3, name: 'Ron Viejo de Caldas (Botella)', buyPrice: 45000, sellPrice: 90000, stock: 10 },
  { id: 4, name: 'Aguardiente Antioqueño (Media)', buyPrice: 25000, sellPrice: 50000, stock: 15 },
  { id: 5, name: 'Agua', buyPrice: 1000, sellPrice: 3000, stock: 30 },
];

export const TABLES = [
  'BARRA',
  'MESA 1',
  'MESA 2',
  'MESA 3',
  'MESA 4',
  'MESA 5',
  'MESA 6'
];

export const INITIAL_TABLES: TableOrder[] = TABLES.map(t => ({
  id: t,
  items: [],
  isOpen: true,
  orderStatus: 'PENDIENTE'
}));

export const formatCOP = (amount: number) => {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};
