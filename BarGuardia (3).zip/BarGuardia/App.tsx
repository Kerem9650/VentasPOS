import React, { useEffect, useState } from 'react';
import { User, Product, Sale, CashRegisterState, TableOrder, ViewState, Role } from './types';
import { INITIAL_USERS, INITIAL_PRODUCTS, INITIAL_TABLES } from './constants';
import { storage } from './services/storage';
import { api } from './services/api';

// Icons
import {
  LayoutDashboard,
  ShoppingCart,
  Archive,
  DollarSign,
  FileBarChart,
  Users,
  LogOut,
  Cloud,
  CloudOff,
  CheckCircle,
  ClipboardList,
  Settings as SettingsIcon,
  X
} from 'lucide-react';

// Components
import { Login } from './components/Login';
import { POS } from './components/POS';
import { Inventory } from './components/Inventory';
import { CashRegister } from './components/CashRegister';
import { Reports } from './components/Reports';
import { AdminUsers } from './components/AdminUsers';
import { Orders } from './components/Orders';
import { Settings } from './components/Settings';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [view, setView] = useState<ViewState>('LOGIN');

  // Application State
  const [users, setUsers] = useState<User[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [tables, setTables] = useState<TableOrder[]>([]);
  const [cashState, setCashState] = useState<CashRegisterState>({
    isOpen: false,
    openingBalance: 0,
    currentSalesCash: 0,
    currentSalesDigital: 0,
    expenses: [],
    openedAt: null,
    closedAt: null
  });

  // Load Data on Mount
  const [connectionStatus, setConnectionStatus] = useState<'checking' | 'connected' | 'error'>('checking');

  // Load Data on Mount
  // Load Data on Mount
  useEffect(() => {
    // 1. Load from LocalStorage (Fast)
    const storedUsers = storage.getUsers(INITIAL_USERS);
    // Ensure initial users are always present
    const mergedUsers = [...storedUsers];
    INITIAL_USERS.forEach(initUser => {
      const index = mergedUsers.findIndex(u => u.username === initUser.username);
      if (index >= 0) {
        mergedUsers[index] = initUser;
      } else {
        mergedUsers.push(initUser);
      }
    });
    setUsers(mergedUsers);

    setProducts(storage.getProducts(INITIAL_PRODUCTS));
    setSales(storage.getSales());

    const storedTables = storage.getTables(INITIAL_TABLES);
    console.log('Loaded tables from storage:', storedTables);
    setTables(storedTables.length > 0 ? storedTables : INITIAL_TABLES);

    setCashState(storage.getCashState({
      isOpen: false,
      openingBalance: 0,
      currentSalesCash: 0,
      currentSalesDigital: 0,
      expenses: [],
      openedAt: null,
      closedAt: null
    }));

    // 2. Fetch from Google Sheets API (Async)
    const fetchData = async () => {
      console.log('Fetching data from Google Sheets...');
      setConnectionStatus('checking');
      try {
        const data = await api.getData();
        if (data) {
          console.log('Data received:', data);
          setConnectionStatus('connected');
          if (data.users && data.users.length > 0) setUsers(data.users);
          if (data.products && data.products.length > 0) setProducts(data.products);
          if (data.sales && Array.isArray(data.sales)) setSales(data.sales);
          if (data.tables && data.tables.length > 0) {
            console.log('Setting tables from API:', data.tables);
            setTables(data.tables);
          }
          if (data.cash) setCashState(data.cash);
        } else {
          setConnectionStatus('error');
        }
      } catch (e) {
        console.error(e);
        setConnectionStatus('error');
      }
    };
    fetchData();
  }, []);

  // Save Data on Change (Sync to LocalStorage + Async to API)
  useEffect(() => {
    storage.saveUsers(users);
    if (users.length > 0 && connectionStatus === 'connected') api.saveUsers(users);
  }, [users, connectionStatus]);

  useEffect(() => {
    storage.saveProducts(products);
    if (products.length > 0 && connectionStatus === 'connected') api.saveProducts(products);
  }, [products, connectionStatus]);

  useEffect(() => {
    storage.saveSales(sales);
    if (sales.length > 0 && connectionStatus === 'connected') api.saveSales(sales);
  }, [sales, connectionStatus]);

  useEffect(() => {
    console.log('Tables changed:', tables);
    storage.saveTables(tables);
    if (tables.length > 0 && connectionStatus === 'connected') api.saveTables(tables);
  }, [tables, connectionStatus]);

  useEffect(() => {
    storage.saveCashState(cashState);
    if (cashState && connectionStatus === 'connected') api.saveCashState(cashState);
  }, [cashState, connectionStatus]);

  // Load Theme on Mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme_config');
    if (savedTheme) {
      try {
        const config = JSON.parse(savedTheme);
        const root = document.documentElement;
        root.style.setProperty('--primary', config.primary);
        root.style.setProperty('--primary-hover', config.primaryHover);
        root.style.setProperty('--bg-main', config.bgMain);
        root.style.setProperty('--bg-paper', config.bgPaper);
        root.style.setProperty('--text-main', config.textMain);
        root.style.setProperty('--text-secondary', config.textSecondary);
      } catch (e) {
        console.error('Failed to load theme config', e);
      }
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    if (user.role === Role.KITCHEN) {
      setView('ORDERS');
    } else {
      setView('DASHBOARD');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setView('LOGIN');
  };

  const handleForceSync = async () => {
    if (confirm('¿Deseas forzar la sincronización de todos los datos a Google Sheets?')) {
      await api.saveUsers(users);
      await api.saveProducts(products);
      await api.saveSales(sales);
      await api.saveTables(tables);
      await api.saveCashState(cashState);
      alert('Sincronización enviada. Verifica tu Google Sheet en unos segundos.');
    }
  };

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  if (!currentUser || view === 'LOGIN') {
    return <Login users={users} onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-app-bg text-app-text overflow-hidden font-sans relative">
      {/* Mobile Menu Button */}
      <button
        className="md:hidden absolute top-4 left-4 z-50 p-2 bg-app-paper rounded border border-gray-700 text-primary"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
      </button>

      {/* Overlay for mobile */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed md:static inset-y-0 left-0 z-50 w-64 bg-app-paper border-r border-gray-700 flex flex-col transition-transform duration-300 transform
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0
      `}>
        <div className="p-6 border-b border-gray-700 flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold text-app-text tracking-wider">Sistema POS</h1>
            <p className="text-xs text-app-text mt-2">Bienvenido, {currentUser.name}</p>
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-gray-700 mt-1 inline-block">{currentUser.role}</span>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="md:hidden text-app-muted">
            <X size={24} />
          </button>
        </div>

        <div className="mt-4 px-6 flex items-center gap-2 text-xs">
          <div className={`w-2 h-2 rounded-full ${connectionStatus === 'connected' ? 'bg-green-500' :
            connectionStatus === 'error' ? 'bg-red-500' : 'bg-yellow-500 animate-pulse'
            }`} />
          <span className={
            connectionStatus === 'connected' ? 'text-green-400' :
              connectionStatus === 'error' ? 'text-red-400' : 'text-yellow-400'
          }>
            {connectionStatus === 'connected' ? 'Nube Conectada' :
              connectionStatus === 'error' ? 'Error de Conexión' : 'Conectando...'}
          </span>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {currentUser.role !== Role.KITCHEN && (
            <>
              <button
                onClick={() => { setView('DASHBOARD'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-colors ${view === 'DASHBOARD' ? 'bg-primary text-app-text' : 'text-app-text hover:bg-gray-700 hover:text-app-text'}`}
              >
                <LayoutDashboard size={20} /> Principal
              </button>

              <button
                onClick={() => { setView('POS'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-colors ${view === 'POS' ? 'bg-primary text-app-text' : 'text-app-text hover:bg-gray-700 hover:text-app-text'}`}
              >
                <ShoppingCart size={20} /> Ventas (Mesas)
              </button>

              {currentUser.role === Role.ADMIN && (
                <>
                  <button
                    onClick={() => { setView('INVENTORY'); setIsSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-colors ${view === 'INVENTORY' ? 'bg-primary text-app-text' : 'text-app-text hover:bg-gray-700 hover:text-app-text'}`}
                  >
                    <Archive size={20} /> Inventario
                  </button>

                  <button
                    onClick={() => { setView('CASH'); setIsSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-colors ${view === 'CASH' ? 'bg-primary text-app-text' : 'text-app-text hover:bg-gray-700 hover:text-app-text'}`}
                  >
                    <DollarSign size={20} /> Caja
                  </button>

                  <button
                    onClick={() => { setView('REPORTS'); setIsSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-colors ${view === 'REPORTS' ? 'bg-primary text-app-text' : 'text-app-text hover:bg-gray-700 hover:text-app-text'}`}
                  >
                    <FileBarChart size={20} /> Reportes
                  </button>
                </>
              )}
            </>
          )}

          <button
            onClick={() => { setView('ORDERS'); setIsSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-colors ${view === 'ORDERS' ? 'bg-primary text-app-text' : 'text-app-text hover:bg-gray-700 hover:text-app-text'}`}
          >
            <ClipboardList size={20} /> Pedidos
          </button>

          {currentUser.role === Role.ADMIN && (
            <>
              <button
                onClick={() => { setView('USERS'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-colors ${view === 'USERS' ? 'bg-primary text-app-text' : 'text-app-text hover:bg-gray-700 hover:text-app-text'}`}
              >
                <Users size={20} /> Usuarios
              </button>

              <button
                onClick={() => { setView('SETTINGS'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-colors ${view === 'SETTINGS' ? 'bg-primary text-app-text' : 'text-app-text hover:bg-gray-700 hover:text-app-text'}`}
              >
                <SettingsIcon size={20} /> Configuración
              </button>
            </>
          )}

          <div className="pt-4 mt-4 border-t border-gray-700">
            <button
              onClick={handleForceSync}
              className="w-full flex items-center gap-2 px-4 py-2 text-xs text-blue-400 hover:bg-blue-900/20 rounded transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" /><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16" /><path d="M16 21h5v-5" /></svg>
              Forzar Sincronización
            </button>
          </div>
        </nav>

        <div className="p-4 border-t border-gray-700">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 justify-center px-4 py-2 text-red-400 hover:bg-red-900/20 hover:text-red-300 rounded transition-colors"
          >
            <LogOut size={18} /> Cerrar Sesión
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-auto bg-app-bg">
        {view === 'DASHBOARD' && (
          <div className="p-10 flex flex-col items-center justify-center h-full text-center">
            <h2 className="text-4xl font-bold text-app-text mb-8">Bienvenido a Sistema POS</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6 max-w-4xl w-full">
              <button onClick={() => setView('POS')} className="bg-app-paper hover:bg-gray-700 p-8 rounded-xl border border-gray-700 flex flex-col items-center gap-4 transition-all">
                <ShoppingCart size={48} className="text-blue-500" />
                <span className="text-xl font-bold">Ir a Ventas</span>
              </button>

              {currentUser.role === Role.ADMIN && (
                <>
                  <button onClick={() => setView('INVENTORY')} className="bg-app-paper hover:bg-gray-700 p-8 rounded-xl border border-gray-700 flex flex-col items-center gap-4 transition-all">
                    <Archive size={48} className="text-green-500" />
                    <span className="text-xl font-bold">Inventario</span>
                  </button>
                  <button onClick={() => setView('CASH')} className="bg-app-paper hover:bg-gray-700 p-8 rounded-xl border border-gray-700 flex flex-col items-center gap-4 transition-all">
                    <DollarSign size={48} className="text-primary" />
                    <span className="text-xl font-bold">Caja</span>
                  </button>
                </>
              )}

              <button onClick={() => setView('ORDERS')} className="bg-app-paper hover:bg-gray-700 p-8 rounded-xl border border-gray-700 flex flex-col items-center gap-4 transition-all">
                <ClipboardList size={48} className="text-purple-500" />
                <span className="text-xl font-bold">Pedidos</span>
              </button>
            </div>
          </div>
        )}

        {view === 'INVENTORY' && (
          <Inventory
            user={currentUser}
            products={products}
            onUpdateProducts={setProducts}
          />
        )}

        {view === 'POS' && (
          <POS
            user={currentUser}
            products={products}
            tables={tables}
            cashState={cashState}
            onUpdateTables={setTables}
            onAddSale={(sale) => setSales([...sales, sale])}
            onUpdateProducts={setProducts}
            onUpdateCash={setCashState}
          />
        )}

        {view === 'CASH' && (
          <CashRegister
            user={currentUser}
            state={cashState}
            onUpdateState={setCashState}
          />
        )}

        {view === 'REPORTS' && (
          <Reports
            user={currentUser}
            sales={sales}
            onUpdateSales={setSales}
          />
        )}

        {view === 'USERS' && (
          <AdminUsers
            currentUser={currentUser}
            users={users}
            onUpdateUsers={setUsers}
          />
        )}

        {view === 'ORDERS' && (
          <Orders tables={tables} onUpdateTables={setTables} />
        )}

        {view === 'SETTINGS' && (
          <Settings />
        )}
      </main>
    </div>
  );
}

export default App;
