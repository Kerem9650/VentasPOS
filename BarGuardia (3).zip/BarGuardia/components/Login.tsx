import React, { useState } from 'react';
import { User } from '../types';
import { Lock, User as UserIcon } from 'lucide-react';

interface LoginProps {
  users: User[];
  onLogin: (user: User) => void;
}

export const Login: React.FC<LoginProps> = ({ users, onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      onLogin(user);
    } else {
      setError('Credenciales incorrectas');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-app-bg p-4">
      <div className="bg-app-paper p-8 rounded-lg shadow-xl w-full max-w-md border border-gray-700">
        <h1 className="text-3xl font-bold text-center text-primary mb-8 font-serif"> POS  Ventas</h1>
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && <div className="bg-red-500/20 text-red-200 p-3 rounded text-sm text-center">{error}</div>}

          <div>
            <label className="block text-app-muted mb-2">Usuario</label>
            <div className="relative">
              <UserIcon className="absolute left-3 top-3 text-app-muted w-5 h-5" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-app-bg text-app-text p-3 pl-10 rounded border border-gray-700 focus:ring-2 focus:ring-primary outline-none"
                placeholder="Ingrese usuario"
              />
            </div>
          </div>

          <div>
            <label className="block text-app-muted mb-2">Contraseña</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 text-app-muted w-5 h-5" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-app-bg text-app-text p-3 pl-10 rounded border border-gray-700 focus:ring-2 focus:ring-primary outline-none"
                placeholder="Ingrese contraseña"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-primary hover:bg-primary-hover text-white font-bold py-3 rounded transition-colors"
          >
            INGRESAR
          </button>
        </form>
      </div>
    </div>
  );
};
