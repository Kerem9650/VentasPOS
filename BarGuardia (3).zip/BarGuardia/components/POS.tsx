import React, { useState } from 'react';
import { Product, TableOrder, Sale, User, CartItem, CashRegisterState } from '../types';
import { formatCOP } from '../constants';
import { ShoppingCart, Plus, Minus, Trash2, CheckCircle, CreditCard, Banknote, X, Printer } from 'lucide-react';

interface POSProps {
  user: User;
  products: Product[];
  tables: TableOrder[];
  cashState: CashRegisterState;
  onUpdateTables: (tables: TableOrder[]) => void;
  onAddSale: (sale: Sale) => void;
  onUpdateProducts: (products: Product[]) => void;
  onUpdateCash: (state: CashRegisterState) => void;
}

export const POS: React.FC<POSProps> = ({
  user, products, tables, cashState,
  onUpdateTables, onAddSale, onUpdateProducts, onUpdateCash
}) => {
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [error, setError] = useState('');

  const currentOrder = tables.find(t => t.id === selectedTable);

  if (!cashState.isOpen) {
    return (
      <div className="flex items-center justify-center h-full text-app-text">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2 text-app-text">Caja Cerrada</h2>
          <p className="text-app-text">Debe abrir la caja para realizar ventas.</p>
        </div>
      </div>
    );
  }

  const handleAddToOrder = (product: Product) => {
    if (!currentOrder) return;
    if (product.stock <= 0) {
      alert('Sin stock disponible');
      return;
    }

    const existingItem = currentOrder.items.find(i => i.productId === product.id);
    let newItems;

    if (existingItem) {
      newItems = currentOrder.items.map(i =>
        i.productId === product.id ? { ...i, quantity: i.quantity + 1 } : i
      );
    } else {
      newItems = [...currentOrder.items, {
        productId: product.id,
        name: product.name,
        quantity: 1,
        price: product.sellPrice
      }];
    }

    // Update table
    onUpdateTables(tables.map(t => t.id === selectedTable ? { ...t, items: newItems, orderStatus: 'PENDIENTE' } : t));
  };

  const updateQuantity = (productId: number, delta: number) => {
    if (!currentOrder) return;

    const newItems = currentOrder.items.map(i => {
      if (i.productId === productId) {
        return { ...i, quantity: Math.max(1, i.quantity + delta) };
      }
      return i;
    });

    onUpdateTables(tables.map(t => t.id === selectedTable ? { ...t, items: newItems, orderStatus: 'PENDIENTE' } : t));
  };

  const removeItem = (productId: number) => {
    if (!currentOrder) return;
    const newItems = currentOrder.items.filter(i => i.productId !== productId);
    onUpdateTables(tables.map(t => t.id === selectedTable ? { ...t, items: newItems, orderStatus: newItems.length === 0 ? null : t.orderStatus } : t));
  };

  const calculateTotal = () => {
    return currentOrder ? currentOrder.items.reduce((acc, i) => acc + (i.price * i.quantity), 0) : 0;
  };

  const processSale = (method: 'EFECTIVO' | 'DIGITAL') => {
    if (!currentOrder || currentOrder.items.length === 0) return;

    // Check stock again
    for (const item of currentOrder.items) {
      const prod = products.find(p => p.id === item.productId);
      if (!prod || prod.stock < item.quantity) {
        setError(`No hay suficiente stock para ${item.name}`);
        return;
      }
    }

    const total = calculateTotal();
    const newSale: Sale = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      total,
      paymentMethod: method,
      tableName: currentOrder.id,
      items: [...currentOrder.items],
      sellerName: user.name
    };

    // 1. Save Sale
    onAddSale(newSale);

    // 2. Update Inventory
    const updatedProducts = products.map(p => {
      const soldItem = currentOrder.items.find(i => i.productId === p.id);
      if (soldItem) {
        return { ...p, stock: p.stock - soldItem.quantity };
      }
      return p;
    });
    onUpdateProducts(updatedProducts);

    // 3. Update Cash Register
    onUpdateCash({
      ...cashState,
      currentSalesCash: method === 'EFECTIVO' ? cashState.currentSalesCash + total : cashState.currentSalesCash,
      currentSalesDigital: method === 'DIGITAL' ? cashState.currentSalesDigital + total : cashState.currentSalesDigital,
    });

    // 4. Clear Table
    onUpdateTables(tables.map(t => t.id === selectedTable ? { ...t, items: [], orderStatus: null } : t));

    // Set receipt sale before clearing selection
    setLastSale(newSale);

    setShowPaymentModal(false);
    setSelectedTable(null);
    setError('');
  };

  const handlePreviewReceipt = () => {
    if (!currentOrder) return;
    const total = calculateTotal();
    const previewSale: Sale = {
      id: "PREVIEW-" + Date.now().toString().slice(-6),
      date: new Date().toISOString(),
      total,
      paymentMethod: 'PENDIENTE',
      tableName: currentOrder.id,
      items: [...currentOrder.items],
      sellerName: user.name
    };
    setLastSale(previewSale);
  };

  const [lastSale, setLastSale] = useState<Sale | null>(null);

  const ReceiptModal = ({ sale, onClose }: { sale: Sale, onClose: () => void }) => {
    const handlePrint = () => {
      const receiptContent = document.getElementById('receipt-content');
      if (!receiptContent) return;

      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(`
          <html>
            <head>
              <title>Recibo - ${sale.id}</title>
              <style>
                @page { margin: 0; size: auto; }
                body { 
                  font-family: 'Courier New', Courier, monospace; 
                  width: 100%; 
                  max-width: 300px;
                  margin: 0; 
                  padding: 10px 5px;
                  color: black; 
                }
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                .text-left { text-align: left; }
                .font-bold { font-weight: bold; }
                .text-sm { font-size: 12px; }
                .text-xs { font-size: 10px; }
                .border-b { border-bottom: 1px dashed #000; }
                .border-t { border-top: 1px dashed #000; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
                td, th { padding: 4px 0; }
                .my-2 { margin: 10px 0; }
                .mb-4 { margin-bottom: 15px; }
              </style>
            </head>
            <body>
              <div class="text-center mb-4">
                <h2 style="margin:0; font-size: 16px; font-weight: 900;">SISTEMA POS</h2>
                <p class="text-xs">Nit: 900.123.456-7</p>
                <p class="text-xs">Calle Principal # 12-34</p>
                <p class="text-xs">${new Date(sale.date).toLocaleString()}</p>
              </div>

              <div class="border-b mb-4 text-sm">
                <div style="display:flex; justify-content:space-between;"><span>Recibo:</span> <span class="font-bold">${sale.id.startsWith('PREVIEW') ? 'CUENTA' : sale.id.slice(0, 8)}</span></div>
                <div style="display:flex; justify-content:space-between;"><span>Mesa:</span> <span class="font-bold">${sale.tableName}</span></div>
                <div style="display:flex; justify-content:space-between;"><span>Atendió:</span> <span>${sale.sellerName}</span></div>
              </div>

              <table class="text-sm">
                <thead>
                  <tr class="border-b">
                    <th class="text-left" style="width: 15%">Cant</th>
                    <th class="text-left" style="width: 55%">Prod</th>
                    <th class="text-right" style="width: 30%">Total</th>
                  </tr>
                </thead>
                <tbody>
                  ${sale.items.map(item => `
                    <tr>
                      <td class="text-center">${item.quantity}</td>
                      <td>${item.name}</td>
                      <td class="text-right">${formatCOP(item.price * item.quantity)}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>

              <div class="border-t pt-2 text-sm">
                <div style="display:flex; justify-content:space-between; font-weight:bold; font-size: 16px;">
                  <span>TOTAL</span>
                  <span>${formatCOP(sale.total)}</span>
                </div>
                ${sale.paymentMethod !== 'PENDIENTE' ? `
                <div style="display:flex; justify-content:space-between; margin-top:5px; font-size:12px;">
                  <span>Método Pago:</span>
                  <span>${sale.paymentMethod}</span>
                </div>` : ''}
              </div>

              <div class="text-center text-xs my-2" style="margin-top: 20px;">
                <p>¡Gracias por su visita!</p>
              </div>
            </body>
          </html>
        `);
        doc.close();
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();

        setTimeout(() => {
          document.body.removeChild(iframe);
        }, 1000);
      }
    };

    return (
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
        <div className="bg-white text-black p-6 rounded-lg max-w-sm w-full max-h-[90vh] overflow-y-auto flex flex-col gap-4 relative shadow-2xl">
          <button onClick={onClose} className="absolute top-2 right-2 text-gray-500 hover:text-gray-800">
            <X size={24} />
          </button>

          <div id="receipt-content" className="flex flex-col gap-2 p-2 bg-white">
            <div className="text-center border-b-2 border-dashed border-gray-300 pb-4 mb-2">
              <h2 className="text-xl font-black uppercase tracking-wider">SISTEMA POS</h2>
              <p className="text-xs text-gray-500">Nit: 900.123.456-7</p>
              <p className="text-xs text-gray-500">Calle Principal # 12-34</p>
              <p className="text-xs text-gray-500">{new Date(sale.date).toLocaleString()}</p>
            </div>

            <div className="flex flex-col gap-1 text-sm border-b-2 border-dashed border-gray-300 pb-4 mb-2">
              <div className="flex justify-between"><span>Recibo:</span> <span className="font-mono">{sale.id.startsWith('PREVIEW') ? 'CUENTA' : sale.id.slice(0, 8)}</span></div>
              <div className="flex justify-between"><span>Mesa:</span> <span className="font-bold">{sale.tableName}</span></div>
              <div className="flex justify-between"><span>Atendió:</span> <span>{sale.sellerName}</span></div>
            </div>

            <table className="w-full text-sm text-left mb-2">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="py-1 w-8">Cant</th>
                  <th className="py-1">Prod</th>
                  <th className="py-1 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {sale.items.map((item, i) => (
                  <tr key={i} className="">
                    <td className="py-1 align-top text-center">{item.quantity}</td>
                    <td className="py-1 align-top leading-tight">{item.name}</td>
                    <td className="py-1 align-top text-right whitespace-nowrap">{formatCOP(item.price * item.quantity)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="flex flex-col gap-1 text-sm border-t-2 border-dashed border-gray-300 pt-2">
              <div className="flex justify-between font-bold text-lg">
                <span>TOTAL</span>
                <span>{formatCOP(sale.total)}</span>
              </div>
              <div className="flex justify-between text-gray-600 text-xs mt-1">
                <span>Método Pago:</span>
                <span>{sale.paymentMethod}</span>
              </div>
            </div>

            <div className="text-center text-xs text-gray-500 mt-4 pt-4 border-t border-gray-200">
              <p className="font-semibold">¡Gracias por su visita!</p>
              <p className="italic mt-1">Software: Sistema POS</p>
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <button onClick={handlePrint} className="flex-1 bg-app-paper text-white py-2 rounded flex items-center justify-center gap-2 hover:bg-gray-700 transition-colors">
              <Printer size={18} /> Imprimir
            </button>
            <button onClick={onClose} className="flex-1 bg-gray-200 text-gray-800 py-2 rounded hover:bg-gray-300 transition-colors">
              Cerrar
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col md:flex-row h-full bg-app-bg text-app-text overflow-hidden">
      {/* Tables Grid */}
      <div className={`${selectedTable ? 'h-1/2 md:h-full md:w-1/2' : 'h-full w-full'} p-4 md:p-6 transition-all duration-300 overflow-y-auto`}>
        <h2 className="text-2xl font-bold mb-6 text-app-text">Mesas</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {tables.map(table => {
            const total = table.items.reduce((acc, i) => acc + (i.price * i.quantity), 0);
            const hasItems = table.items.length > 0;
            return (
              <button
                key={table.id}
                onClick={() => setSelectedTable(table.id)}
                className={`p-6 rounded-lg border-2 flex flex-col items-center justify-center gap-2 transition-all ${selectedTable === table.id
                  ? 'border-primary bg-primary/30'
                  : hasItems ? 'border-blue-500 bg-app-paper' : 'border-gray-700 bg-app-paper hover:bg-gray-750'
                  }`}
              >
                <span className="text-lg font-bold">{table.id}</span>
                {hasItems ? (
                  <span className="text-primary font-mono font-bold">{formatCOP(total)}</span>
                ) : (
                  <span className="text-app-muted text-sm">Disponible</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Order Panel */}
      {selectedTable && currentOrder && (
        <div className="h-1/2 md:h-full w-full md:w-1/2 bg-app-paper border-t md:border-t-0 md:border-l border-gray-700 flex flex-col shadow-2xl md:shadow-none z-10">
          <div className="p-4 border-b border-gray-700 flex justify-between items-center bg-app-paper">
            <h3 className="text-xl font-bold">{selectedTable}</h3>
            <button onClick={() => setSelectedTable(null)} className="text-app-muted hover:text-app-text">
              <span className="sr-only">Cerrar</span>
              ✕
            </button>
          </div>

          {/* Product Selection List (Mini Inventory) */}
          <div className="p-4 border-b border-gray-700 h-1/3 overflow-y-auto">
            <h4 className="text-sm font-semibold text-app-text mb-2">Agregar Productos</h4>
            <div className="grid grid-cols-2 gap-2">
              {products.map(p => (
                <button
                  key={p.id}
                  disabled={p.stock <= 0}
                  onClick={() => handleAddToOrder(p)}
                  className={`relative overflow-hidden group rounded text-left p-0 h-24 border border-gray-700 transition-all ${p.stock > 0
                    ? 'hover:border-primary hover:scale-[1.02]'
                    : 'opacity-50 cursor-not-allowed bg-red-900/10'
                    }`}
                >
                  {/* Background Image/Color */}
                  <div
                    className="absolute inset-0 bg-cover bg-center transition-transform group-hover:scale-110"
                    style={{
                      backgroundImage: p.image ? `url(${p.image})` : 'none',
                      backgroundColor: '#1f2937' // Fallback color
                    }}
                  />

                  {/* Gradient Overlay for Text Readability */}
                  <div className={`absolute inset-0 flex flex-col justify-end p-2 bg-gradient-to-t ${p.image ? 'from-black/90 via-black/50 to-transparent' : 'from-gray-800 to-gray-700'}`}>
                    <span className="font-bold text-sm truncate text-white drop-shadow-md">{p.name}</span>
                    <div className="flex justify-between items-end">
                      <span className="text-green-400 font-bold text-xs">{formatCOP(p.sellPrice)}</span>
                      <span className={`text-[10px] font-bold px-1 rounded ${p.stock <= 0 ? 'text-red-500 bg-black/50' : 'text-gray-300 bg-black/30'}`}>
                        {p.stock <= 0 ? 'AGOTADO' : `Cant: ${p.stock}`}
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Current Items */}
          <div className="flex-1 overflow-y-auto p-4">
            <table className="w-full text-sm">
              <thead className="text-app-muted border-b border-gray-700">
                <tr>
                  <th className="text-left py-2">Producto</th>
                  <th className="text-center py-2">Cant.</th>
                  <th className="text-right py-2">Total</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {currentOrder.items.map(item => (
                  <tr key={item.productId} className="border-b border-gray-700/50">
                    <td className="py-3">{item.name}</td>
                    <td className="py-3 flex justify-center items-center gap-2">
                      <button onClick={() => updateQuantity(item.productId, -1)} className="p-1 hover:bg-gray-700 rounded"><Minus size={14} /></button>
                      <span className="w-6 text-center">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, 1)} className="p-1 hover:bg-gray-700 rounded"><Plus size={14} /></button>
                    </td>
                    <td className="py-3 text-right">{formatCOP(item.price * item.quantity)}</td>
                    <td className="py-3 text-right">
                      <button onClick={() => removeItem(item.productId)} className="text-red-400 hover:text-red-300"><Trash2 size={16} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Footer Actions */}
          <div className="p-4 bg-app-paper border-t border-gray-700">
            <div className="flex justify-between items-center mb-4 text-xl font-bold">
              <span>Total:</span>
              <span className="text-green-400">{formatCOP(calculateTotal())}</span>
            </div>
            <button
              onClick={() => setShowPaymentModal(true)}
              disabled={currentOrder.items.length === 0}
              className="w-full bg-primary hover:bg-primary-hover disabled:bg-gray-700 disabled:text-gray-500 text-white font-bold py-3 rounded flex justify-center items-center gap-2"
            >
              <CheckCircle size={20} />
              CERRAR VENTA
            </button>
            <button
              onClick={handlePreviewReceipt}
              disabled={currentOrder.items.length === 0}
              className="w-full mt-2 bg-gray-700 hover:bg-gray-600 disabled:bg-app-paper disabled:text-gray-600 text-white font-bold py-3 rounded flex justify-center items-center gap-2"
            >
              <Printer size={20} />
              VER FACTURA
            </button>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-app-paper p-8 rounded-lg max-w-md w-full border border-gray-600">
            <h3 className="text-2xl font-bold mb-4 text-center">Finalizar Venta - {selectedTable}</h3>
            <p className="text-center text-3xl font-bold text-green-400 mb-8">{formatCOP(calculateTotal())}</p>

            {error && <p className="text-red-400 text-center mb-4">{error}</p>}

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => processSale('EFECTIVO')}
                className="bg-green-600 hover:bg-green-700 p-4 rounded flex flex-col items-center gap-2"
              >
                <Banknote size={32} />
                <span>Efectivo</span>
              </button>
              <button
                onClick={() => processSale('DIGITAL')}
                className="bg-blue-600 hover:bg-blue-700 p-4 rounded flex flex-col items-center gap-2"
              >
                <CreditCard size={32} />
                <span>Digital / Transferencia</span>
              </button>
            </div>
            <button
              onClick={() => { setShowPaymentModal(false); setError(''); }}
              className="mt-6 w-full text-app-muted hover:text-app-text py-2"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Receipt Modal */}
      {lastSale && (
        <ReceiptModal sale={lastSale} onClose={() => setLastSale(null)} />
      )}
    </div>
  );
};
