import React, { useState } from 'react';
import { Sale, User, Role } from '../types';
import { formatCOP } from '../constants';
import { Download, Edit, Save, X } from 'lucide-react';

interface ReportsProps {
  user: User;
  sales: Sale[];
  onUpdateSales: (sales: Sale[]) => void;
}

export const Reports: React.FC<ReportsProps> = ({ user, sales, onUpdateSales }) => {
  const [filterDate, setFilterDate] = useState(new Date().toISOString().split('T')[0]);
  const [editingSaleId, setEditingSaleId] = useState<string | null>(null);
  const [editTotal, setEditTotal] = useState<number>(0);

  const isAdmin = user.role === Role.ADMIN;

  const filteredSales = sales.filter(s => s.date.startsWith(filterDate));

  const totalDaily = filteredSales.reduce((acc, s) => acc + s.total, 0);

  const handleEdit = (sale: Sale) => {
    if (!isAdmin) return;
    setEditingSaleId(sale.id);
    setEditTotal(sale.total);
  };

  const saveEdit = () => {
    if (!editingSaleId) return;
    const updated = sales.map(s => s.id === editingSaleId ? { ...s, total: editTotal } : s);
    onUpdateSales(updated);
    setEditingSaleId(null);
  };

  const downloadCSV = (period: 'daily' | 'monthly') => {
    const csvRows = [
      ['ID Venta', 'Fecha', 'Mesa', 'Vendedor', 'Metodo Pago', 'Total', 'Productos (Detalle)']
    ];

    let exportSales = [];
    if (period === 'daily') {
      exportSales = filteredSales;
    } else {
      const monthPrefix = filterDate.substring(0, 7); // YYYY-MM
      exportSales = sales.filter(s => s.date.startsWith(monthPrefix));
    }

    exportSales.forEach(s => {
      // Formato: 2x Cerveza ($5.000)
      const itemsStr = s.items.map(i => `${i.quantity}x ${i.name} (${formatCOP(i.price)})`).join('; ');
      csvRows.push([
        s.id,
        new Date(s.date).toLocaleString(),
        s.tableName,
        s.sellerName,
        s.paymentMethod,
        s.total.toString(),
        `"${itemsStr}"`
      ]);
    });

    const csvContent = "data:text/csv;charset=utf-8," + csvRows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `reporte_ventas_${period}_${filterDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 bg-app-bg min-h-full">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <h2 className="text-2xl font-bold text-app-text">Reporte de Ventas</h2>
        <div className="flex items-center gap-4">
          <input
            type="date"
            value={filterDate}
            onChange={e => setFilterDate(e.target.value)}
            className="bg-app-paper text-app-text p-2 rounded border border-gray-600"
          />
          <button onClick={() => downloadCSV('daily')} className="bg-green-600 hover:bg-green-700 text-app-text px-3 py-2 rounded flex items-center gap-2 text-sm">
            <Download size={16} /> Excel (Día)
          </button>
          <button onClick={() => downloadCSV('monthly')} className="bg-blue-600 hover:bg-blue-700 text-app-text px-3 py-2 rounded flex items-center gap-2 text-sm">
            <Download size={16} /> Excel (Mes)
          </button>
        </div>
      </div>

      <div className="bg-app-paper p-4 rounded mb-6 border-l-4 border-primary">
        <p className="text-app-text">Total Ventas (Día Seleccionado)</p>
        <p className="text-3xl font-bold text-app-text">{formatCOP(totalDaily)}</p>
      </div>

      <div className="bg-app-paper rounded overflow-hidden border border-gray-700">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-700 text-app-text">
            <tr>
              <th className="p-3">Hora</th>
              <th className="p-3">Mesa</th>
              <th className="p-3 w-5/12">Productos Vendidos</th>
              <th className="p-3">Método</th>
              <th className="p-3">Vendedor</th>
              <th className="p-3 text-right">Total</th>
              {isAdmin && <th className="p-3">Acciones</th>}
            </tr>
          </thead>
          <tbody>
            {filteredSales.length === 0 ? (
              <tr><td colSpan={7} className="p-4 text-center text-app-text">No hay ventas registradas este día.</td></tr>
            ) : (
              filteredSales.map(sale => (
                <tr key={sale.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                  <td className="p-3 align-top text-app-muted">{new Date(sale.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                  <td className="p-3 font-bold text-primary align-top">{sale.tableName}</td>
                  <td className="p-3 text-app-text align-top">
                    <ul className="list-disc list-inside bg-app-bg/50 p-2 rounded">
                      {sale.items.map((item, idx) => (
                        <li key={idx} className="text-xs py-0.5">
                          <span className="font-bold text-primary">{item.quantity}x</span> {item.name}
                          <span className="text-app-muted ml-1">({formatCOP(item.price)})</span>
                        </li>
                      ))}
                    </ul>
                  </td>
                  <td className="p-3 align-top">
                    <span className={`px-2 py-1 rounded text-xs ${sale.paymentMethod === 'EFECTIVO' ? 'bg-green-900 text-green-300' : 'bg-blue-900 text-blue-300'}`}>
                      {sale.paymentMethod}
                    </span>
                  </td>
                  <td className="p-3 align-top">{sale.sellerName}</td>
                  <td className="p-3 text-right font-bold align-top">
                    {editingSaleId === sale.id ? (
                      <input
                        type="number"
                        value={editTotal}
                        onChange={e => setEditTotal(Number(e.target.value))}
                        className="w-24 bg-app-bg p-1 rounded text-right border border-primary"
                      />
                    ) : (
                      formatCOP(sale.total)
                    )}
                  </td>
                  {isAdmin && (
                    <td className="p-3 flex justify-center gap-2 align-top">
                      {editingSaleId === sale.id ? (
                        <>
                          <button onClick={saveEdit} className="text-green-400 hover:bg-gray-700 p-1 rounded"><Save size={16} /></button>
                          <button onClick={() => setEditingSaleId(null)} className="text-red-400 hover:bg-gray-700 p-1 rounded"><X size={16} /></button>
                        </>
                      ) : (
                        <button onClick={() => handleEdit(sale)} className="text-app-muted hover:text-app-text hover:bg-gray-700 p-1 rounded"><Edit size={16} /></button>
                      )}
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};