
import React, { useState } from 'react';
import { CashRegisterState, Expense, User } from '../types';
import { formatCOP } from '../constants';
import { Lock, Unlock, DollarSign, AlertTriangle, X, CheckCircle } from 'lucide-react';

interface CashRegisterProps {
  user: User;
  state: CashRegisterState;
  onUpdateState: (state: CashRegisterState) => void;
}

export const CashRegister: React.FC<CashRegisterProps> = ({ user, state, onUpdateState }) => {
  const [openingAmount, setOpeningAmount] = useState<string>('');
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');

  // State for Close Modal
  const [showCloseModal, setShowCloseModal] = useState(false);

  const handleOpen = () => {
    const amount = Number(openingAmount);
    if (isNaN(amount)) return alert('Monto inválido');

    onUpdateState({
      isOpen: true,
      openingBalance: amount,
      currentSalesCash: 0,
      currentSalesDigital: 0,
      expenses: [],
      openedAt: new Date().toISOString(),
      closedAt: null
    });
    setOpeningAmount('');
  };

  const handleAddExpense = () => {
    if (!expenseDesc || !expenseAmount) return;
    const amount = Number(expenseAmount);
    if (isNaN(amount)) return;

    const expense: Expense = {
      id: crypto.randomUUID(),
      description: expenseDesc,
      amount,
      date: new Date().toISOString(),
      registeredBy: user.name
    };

    onUpdateState({
      ...state,
      expenses: [...state.expenses, expense]
    });
    setExpenseDesc('');
    setExpenseAmount('');
  };

  const confirmCloseRegister = () => {
    onUpdateState({
      ...state,
      isOpen: false,
      closedAt: new Date().toISOString()
    });
    setShowCloseModal(false);
  };

  // Calculations
  const totalExpenses = state.expenses.reduce((acc, e) => acc + e.amount, 0);
  const totalCashInDrawer = state.openingBalance + state.currentSalesCash - totalExpenses;
  const grandTotalSales = state.currentSalesCash + state.currentSalesDigital;
  const netProfit = grandTotalSales - totalExpenses;

  // VIEW: CLOSED STATE (OPENING FORM)
  if (!state.isOpen) {
    return (
      <div className="flex items-center justify-center h-full bg-app-bg">
        <div className="bg-app-paper p-8 rounded-lg border border-gray-700 max-w-md w-full text-center shadow-xl">
          <div className="bg-amber-900/30 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="text-primary w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold mb-4 text-app-text">Apertura de Caja</h2>
          <div className="mb-6">
            <label className="block text-left text-app-text text-sm mb-2">Base Inicial (Efectivo en Cajón)</label>
            <div className="relative">
              <span className="absolute left-3 top-3 text-gray-500">$</span>
              <input
                type="number"
                value={openingAmount}
                onChange={e => setOpeningAmount(e.target.value)}
                className="w-full bg-app-bg p-3 pl-8 rounded text-app-text border border-gray-600 focus:border-primary outline-none"
                placeholder="0"
              />
            </div>
          </div>
          <button
            onClick={handleOpen}
            className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded transition-colors flex justify-center items-center gap-2"
          >
            <Unlock size={20} /> ABRIR CAJA
          </button>
        </div>
      </div>
    );
  }

  // VIEW: OPEN STATE (DASHBOARD)
  return (
    <div className="p-6 bg-app-bg min-h-full relative">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h2 className="text-2xl font-bold text-primary flex items-center gap-2">
            <Unlock size={24} /> Control de Caja
          </h2>
          <p className="text-app-muted text-sm mt-1">
            Abierto por: <span className="text-white font-medium">{user.name}</span> •
            {state.openedAt && new Date(state.openedAt).toLocaleTimeString()}
          </p>
        </div>
        <button
          onClick={() => setShowCloseModal(true)}
          className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded font-bold shadow-lg shadow-red-900/20 transition-all hover:scale-105"
        >
          CERRAR CAJA
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-app-paper p-4 rounded border-l-4 border-blue-500 shadow-lg">
          <p className="text-app-muted text-sm">Base Inicial</p>
          <p className="text-2xl font-bold">{formatCOP(state.openingBalance)}</p>
        </div>
        <div className="bg-app-paper p-4 rounded border-l-4 border-green-500 shadow-lg">
          <p className="text-app-muted text-sm">Ventas Efectivo</p>
          <p className="text-2xl font-bold text-green-400">{formatCOP(state.currentSalesCash)}</p>
        </div>
        <div className="bg-app-paper p-4 rounded border-l-4 border-indigo-500 shadow-lg">
          <p className="text-app-muted text-sm">Ventas Digitales</p>
          <p className="text-2xl font-bold text-indigo-400">{formatCOP(state.currentSalesDigital)}</p>
        </div>
        <div className="bg-app-paper p-4 rounded border-l-4 border-primary shadow-lg relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <DollarSign size={48} />
          </div>
          <p className="text-app-muted text-sm">Debe haber en Efectivo</p>
          <p className="text-2xl font-bold text-white">{formatCOP(totalCashInDrawer)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Expenses Section */}
        <div className="bg-app-paper p-6 rounded border border-gray-700 shadow-lg">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-red-400">
            <AlertTriangle size={20} /> Registrar Gastos / Salidas
          </h3>
          <div className="flex gap-2 mb-4">
            <input
              placeholder="Descripción del gasto"
              value={expenseDesc}
              onChange={e => setExpenseDesc(e.target.value)}
              className="flex-1 bg-app-bg p-2 rounded text-app-text border border-gray-600 focus:border-red-500 outline-none"
            />
            <input
              type="number"
              placeholder="Valor"
              value={expenseAmount}
              onChange={e => setExpenseAmount(e.target.value)}
              className="w-32 bg-app-bg p-2 rounded text-app-text border border-gray-600 focus:border-red-500 outline-none"
            />
            <button
              onClick={handleAddExpense}
              className="bg-red-600 hover:bg-red-700 px-4 rounded text-white transition-colors"
            >
              <DollarSign />
            </button>
          </div>

          <div className="overflow-y-auto max-h-60 pr-2">
            <table className="w-full text-sm">
              <thead className="text-app-muted text-left border-b border-gray-700">
                <tr>
                  <th className="py-2">Descripción</th>
                  <th className="py-2 text-right">Valor</th>
                </tr>
              </thead>
              <tbody>
                {state.expenses.length === 0 ? (
                  <tr><td colSpan={2} className="text-center py-4 text-gray-600">No hay gastos registrados</td></tr>
                ) : (
                  state.expenses.map(exp => (
                    <tr key={exp.id} className="border-b border-gray-700/50">
                      <td className="py-2">{exp.description} <span className="text-xs text-gray-500">({exp.registeredBy})</span></td>
                      <td className="py-2 text-right text-red-400">-{formatCOP(exp.amount)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Summary */}
        <div className="bg-app-paper p-6 rounded border border-gray-700 shadow-lg flex flex-col justify-center">
          <h3 className="text-xl font-bold mb-6 text-center text-app-text">Resumen del Turno Actual</h3>
          <div className="space-y-4 text-lg px-4">
            <div className="flex justify-between items-center">
              <span className="text-app-muted">Ventas Totales:</span>
              <span className="font-bold text-green-400 text-xl">{formatCOP(grandTotalSales)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-app-muted">Gastos Totales:</span>
              <span className="font-bold text-red-400 text-xl">-{formatCOP(totalExpenses)}</span>
            </div>
            <div className="h-px bg-gray-600 my-4"></div>
            <div className="flex justify-between items-center text-xl font-bold bg-gray-700/50 p-4 rounded-lg">
              <span className="text-app-text">Ganancia Neta:</span>
              <span className="text-primary">{formatCOP(netProfit)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* CLOSE REGISTER MODAL */}
      {showCloseModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-app-paper rounded-lg max-w-lg w-full border border-gray-600 shadow-2xl overflow-hidden">
            <div className="bg-gray-700 p-4 flex justify-between items-center border-b border-gray-600">
              <h3 className="text-xl font-bold text-app-text flex items-center gap-2">
                <AlertTriangle className="text-primary" /> Confirmar Cierre de Caja
              </h3>
              <button onClick={() => setShowCloseModal(false)} className="text-app-muted hover:text-white">
                <X size={24} />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-app-muted text-center mb-6">
                Al cerrar la caja, se finalizará el turno actual. Verifique que el dinero en efectivo coincida.
              </p>

              <div className="bg-app-bg p-4 rounded-lg space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-app-muted">Base Inicial:</span>
                  <span className="text-app-text">{formatCOP(state.openingBalance)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-app-muted">Ventas Efectivo:</span>
                  <span className="text-green-400">+{formatCOP(state.currentSalesCash)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-app-muted">Gastos/Salidas:</span>
                  <span className="text-red-400">-{formatCOP(totalExpenses)}</span>
                </div>
                <div className="border-t border-gray-700 pt-2 flex justify-between font-bold text-lg">
                  <span className="text-primary">Efectivo a Entregar:</span>
                  <span className="text-app-text">{formatCOP(totalCashInDrawer)}</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-gray-700/50 border-t border-gray-600 flex gap-4">
              <button
                onClick={() => setShowCloseModal(false)}
                className="flex-1 px-4 py-3 bg-gray-600 hover:bg-gray-500 rounded text-white font-medium transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={confirmCloseRegister}
                className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 rounded text-white font-bold transition-colors flex justify-center items-center gap-2"
              >
                <CheckCircle size={20} /> FINALIZAR TURNO
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};