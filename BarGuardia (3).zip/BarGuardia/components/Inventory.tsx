import React, { useState } from 'react';
import { Product, Role, User } from '../types';
import { formatCOP } from '../constants';
import { Plus, Trash2, Edit2, Save, X, AlertTriangle } from 'lucide-react';

interface InventoryProps {
  user: User;
  products: Product[];
  onUpdateProducts: (products: Product[]) => void;
}

export const Inventory: React.FC<InventoryProps> = ({ user, products, onUpdateProducts }) => {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<Partial<Product>>({});

  // New product state
  const [isAdding, setIsAdding] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({ name: '', buyPrice: 0, sellPrice: 0, stock: 0 });

  // Delete modal state
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  const isAdmin = user.role === Role.ADMIN;

  const handleEdit = (product: Product) => {
    if (!isAdmin) return;
    setEditingId(product.id);
    setEditForm(product);
  };

  const saveEdit = () => {
    if (!editingId) return;
    const updated = products.map(p => p.id === editingId ? { ...p, ...editForm } as Product : p);
    onUpdateProducts(updated);
    setEditingId(null);
  };

  const requestDelete = (product: Product) => {
    if (!isAdmin) return;
    setProductToDelete(product);
  };

  const confirmDelete = () => {
    if (productToDelete) {
      onUpdateProducts(products.filter(p => p.id !== productToDelete.id));
      setProductToDelete(null);
    }
  };

  const addNewProduct = () => {
    if (!newProduct.name) return;
    const maxId = products.length > 0 ? Math.max(...products.map(p => p.id)) : 0;
    const product: Product = {
      id: maxId + 1,
      name: newProduct.name!,
      buyPrice: Number(newProduct.buyPrice) || 0,
      sellPrice: Number(newProduct.sellPrice) || 0,
      stock: Number(newProduct.stock) || 0
    };
    onUpdateProducts([...products, product]);
    setIsAdding(false);
    setNewProduct({ name: '', buyPrice: 0, sellPrice: 0, stock: 0 });
  };

  const totalInvValue = products.reduce((acc, p) => acc + (p.buyPrice * p.stock), 0);
  const potentialRevenue = products.reduce((acc, p) => acc + (p.sellPrice * p.stock), 0);

  return (
    <div className="p-6 bg-app-bg min-h-full">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-app-text">Inventario</h2>
        {isAdmin && (
          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-white"
          >
            <Plus size={20} /> Nuevo Producto
          </button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-app-paper p-4 rounded border border-gray-700">
          <p className="text-app-text">Valor Total en Costo</p>
          <p className="text-2xl font-bold text-app-text">{formatCOP(totalInvValue)}</p>
        </div>
        <div className="bg-app-paper p-4 rounded border border-gray-700">
          <p className="text-app-text">Valor Potencial en Venta</p>
          <p className="text-2xl font-bold text-app-text">{formatCOP(potentialRevenue)}</p>
        </div>
      </div>

      {/* Add Product Form */}
      {isAdding && (
        <div className="bg-app-paper p-4 rounded mb-6 border border-primary/50">
          <h3 className="text-lg font-bold mb-4">Agregar Producto</h3>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <input
              placeholder="Nombre"
              value={newProduct.name}
              onChange={e => setNewProduct({ ...newProduct, name: e.target.value })}
              className="bg-app-bg p-2 rounded text-app-text border border-gray-700"
            />
            <input
              type="number"
              placeholder="Precio Compra"
              value={newProduct.buyPrice}
              onChange={e => setNewProduct({ ...newProduct, buyPrice: Number(e.target.value) })}
              className="bg-app-bg p-2 rounded text-app-text border border-gray-700"
            />
            <input
              type="number"
              placeholder="Precio Venta"
              value={newProduct.sellPrice}
              onChange={e => setNewProduct({ ...newProduct, sellPrice: Number(e.target.value) })}
              className="bg-app-bg p-2 rounded text-app-text border border-gray-700"
            />
            <input
              type="number"
              placeholder="Stock Inicial"
              value={newProduct.stock}
              onChange={e => setNewProduct({ ...newProduct, stock: Number(e.target.value) })}
              className="bg-app-bg p-2 rounded text-app-text border border-gray-700"
            />
            <div className="flex gap-2">
              <button onClick={addNewProduct} className="flex-1 bg-green-600 hover:bg-green-700 rounded text-white">Guardar</button>
              <button onClick={() => setIsAdding(false)} className="flex-1 bg-red-600 hover:bg-red-700 rounded text-white">Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto bg-app-paper rounded border border-gray-700">
        <table className="w-full text-left">
          <thead className="bg-gray-700 text-app-text">
            <tr>
              <th className="p-3">ID</th>
              <th className="p-3">Producto</th>
              <th className="p-3">Precio Compra</th>
              <th className="p-3">Precio Venta</th>
              <th className="p-3">Stock</th>
              {isAdmin && <th className="p-3">Acciones</th>}
            </tr>
          </thead>
          <tbody>
            {products.map(product => (
              <tr key={product.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                {editingId === product.id ? (
                  <>
                    <td className="p-3 text-app-muted">{product.id}</td>
                    <td className="p-3"><input className="bg-app-bg w-full p-1 rounded" value={editForm.name} onChange={e => setEditForm({ ...editForm, name: e.target.value })} /></td>
                    <td className="p-3"><input type="number" className="bg-app-bg w-full p-1 rounded" value={editForm.buyPrice} onChange={e => setEditForm({ ...editForm, buyPrice: Number(e.target.value) })} /></td>
                    <td className="p-3"><input type="number" className="bg-app-bg w-full p-1 rounded" value={editForm.sellPrice} onChange={e => setEditForm({ ...editForm, sellPrice: Number(e.target.value) })} /></td>
                    <td className="p-3"><input type="number" className="bg-app-bg w-full p-1 rounded" value={editForm.stock} onChange={e => setEditForm({ ...editForm, stock: Number(e.target.value) })} /></td>
                    <td className="p-3 flex gap-2">
                      <button onClick={saveEdit} className="text-green-400 hover:text-green-300"><Save size={18} /></button>
                      <button onClick={() => setEditingId(null)} className="text-red-400 hover:text-red-300"><X size={18} /></button>
                    </td>
                  </>
                ) : (
                  <>
                    <td className="p-3 text-app-muted">{product.id}</td>
                    <td className="p-3 font-medium">{product.name}</td>
                    <td className="p-3 text-app-muted">{formatCOP(product.buyPrice)}</td>
                    <td className="p-3 text-green-400 font-bold">{formatCOP(product.sellPrice)}</td>
                    <td className={`p-3 font-bold ${product.stock < 10 ? 'text-red-500' : 'text-primary'}`}>{product.stock}</td>
                    {isAdmin && (
                      <td className="p-3 flex gap-3">
                        <button onClick={() => handleEdit(product)} className="text-primary hover:text-amber-400"><Edit2 size={18} /></button>
                        <button onClick={() => requestDelete(product)} className="text-red-500 hover:text-red-400"><Trash2 size={18} /></button>
                      </td>
                    )}
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Delete Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-app-paper rounded-lg max-w-sm w-full border border-gray-600 shadow-2xl">
            <div className="p-6 text-center">
              <div className="bg-red-900/30 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="text-red-500 w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-app-text mb-2">¿Eliminar Producto?</h3>
              <p className="text-app-muted mb-6">
                Estás a punto de eliminar <span className="text-app-text font-bold">{productToDelete.name}</span>.
                Esta acción no se puede deshacer.
              </p>
              <div className="flex gap-4">
                <button
                  onClick={() => setProductToDelete(null)}
                  className="flex-1 px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded text-white transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={confirmDelete}
                  className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 rounded text-white font-bold transition-colors"
                >
                  Eliminar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};