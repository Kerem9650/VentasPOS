export enum Role {
  ADMIN = 'ADMIN',
  SELLER = 'SELLER',
  KITCHEN = 'KITCHEN'
}

export interface User {
  id: string;
  username: string;
  password?: string; // Only used for initial check, ideally hashed in real app
  role: Role;
  name: string;
}

export interface Product {
  id: number;
  name: string;
  buyPrice: number;
  sellPrice: number;
  stock: number;
  image?: string;
  dateAdded?: string; // ISO Date YYYY-MM-DD
}

export interface CartItem {
  productId: number;
  name: string;
  quantity: number;
  price: number;
}

export interface TableOrder {
  id: string; // "Barra", "Mesa 1", etc.
  items: CartItem[];
  isOpen: boolean;
  orderStatus?: 'PENDIENTE' | 'ENTREGADO' | null;
}

export interface Sale {
  id: string;
  date: string; // ISO string
  total: number;
  paymentMethod: 'EFECTIVO' | 'DIGITAL' | 'PENDIENTE';
  tableName: string;
  items: CartItem[];
  sellerName: string;
}

export interface CashRegisterState {
  isOpen: boolean;
  openingBalance: number;
  currentSalesCash: number;
  currentSalesDigital: number;
  expenses: Expense[];
  openedAt: string | null;
  closedAt: string | null;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  date: string;
  registeredBy: string;
}

export type ViewState = 'LOGIN' | 'DASHBOARD' | 'POS' | 'INVENTORY' | 'CASH' | 'REPORTS' | 'USERS' | 'ORDERS' | 'SETTINGS';
